-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Geração: Jun 27, 2021 as 06:39 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Banco de Dados: `investtads`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `gestaopessoal`
-- 

CREATE TABLE `gestaopessoal` (
  `email` varchar(30) NOT NULL,
  `hoje` datetime NOT NULL,
  `ganhos` float NOT NULL,
  `despesas` float NOT NULL,
  `investimentos` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Extraindo dados da tabela `gestaopessoal`
-- 

